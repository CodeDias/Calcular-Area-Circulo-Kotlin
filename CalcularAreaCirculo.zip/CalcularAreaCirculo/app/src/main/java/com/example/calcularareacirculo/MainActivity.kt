package com.example.calcularareacirculo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val raio = findViewById<EditText>(R.id.et_raio)

        val btn_calcular = findViewById<Button>(R.id.btn_calcular)
        btn_calcular.setOnClickListener {
            // Extrair valores dos EditText e converter para Int
            val raioInt = raio.text.toString().toIntOrNull() ?: 0

            // Passar os valores inteiros para a função calcular
            calcular(raioInt)
        }
    }
    fun calcular(raio: Int){

        val tv_resultado = findViewById<TextView>(R.id.tv_resultado)
        val medida = (3.14 * (raio * raio)) // calcular a medida da area

        tv_resultado.setText("O valor da Área é:  ${medida}M")

    }
}